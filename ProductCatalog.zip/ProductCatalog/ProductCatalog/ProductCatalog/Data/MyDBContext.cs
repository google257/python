﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using ProductCatalog.Models;

namespace ProductCatalog.Data
{
    public class MyDBContext:DbContext
    {
       public MyDBContext(DbContextOptions<MyDBContext> options) : base(options) { 
        
        }
        public DbSet<Product> Products { get; set; }
       // public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Product>()
                .Property(p => p.category)
                .HasConversion(new EnumToStringConverter<Category>());
           /* modelBuilder.Entity<Employee>()
                .Property(E => E.dpt)
                .HasConversion(new EnumToStringConverter<DEPT>());*/

               
        }


    }
}
