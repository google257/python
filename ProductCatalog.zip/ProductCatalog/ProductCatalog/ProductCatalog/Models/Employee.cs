﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace ProductCatalog.Models
{
    public enum DEPT
    {
        HR, SALES
    }
    [Index(nameof(DEPT), IsUnique = true)]
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Field SHould Not Empty")]
        public string Name { get; set; }
        public string email { get; set; }
        [Required(ErrorMessage = "Field  is Empty")]
        [EnumDataType(typeof(DEPT))]
        public DEPT dpt { get; set; }



    }
}
