﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace ProductCatalog.Models
{
    public enum Category
    {
        BAKERY,GROCERY,DAIRY
    }
    [Index(nameof(category),IsUnique =true)]
    public class Product
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="Field SHould Not Empty")]
        public string Name { get; set; }
        public string Description { get; set; }
        [Required(ErrorMessage ="Field  is Empty")]
        [EnumDataType(typeof(Category))]
        public Category category { get; set; }
        [DataType(DataType.Date)]
        public DateTime mfgDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime expDate { get; set;}


    }
}
